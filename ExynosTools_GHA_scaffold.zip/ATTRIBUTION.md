References:
- bionic-vulkan-wrapper: https://github.com/leegao/bionic-vulkan-wrapper
- Granite: https://github.com/Themaister/Granite
Please respect upstream licenses when integrating code.
