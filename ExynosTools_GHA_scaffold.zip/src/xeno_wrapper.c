/*
 * ExynosTools xeno_wrapper - minimal prototype (safe, non-proprietary)
 * ExynosTools v1.2-functional scaffold.
 */

#include <stdio.h>
#include <stdint.h>

typedef void* PFN_vkVoidFunction;
typedef uint32_t VkResult;

__attribute__((visibility("default"))) PFN_vkVoidFunction vkGetInstanceProcAddr(void* instance, const char* name) {
    (void)instance; (void)name;
    return NULL;
}

__attribute__((visibility("default"))) PFN_vkVoidFunction vkGetDeviceProcAddr(void* device, const char* name) {
    (void)device; (void)name;
    return NULL;
}

__attribute__((visibility("default"))) VkResult vkEnumerateDeviceExtensionProperties(void) {
    return 0;
}
