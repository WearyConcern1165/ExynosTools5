Roadmap (wrapper-focused):
1) Advertise Vulkan extensions and handle features2 pNext.
2) Simple shader cache and performance settings via config files.
3) Per-app profiles for emulator tweaks.
4) CI-built tar.zst artifacts for Winlator Bionic.
