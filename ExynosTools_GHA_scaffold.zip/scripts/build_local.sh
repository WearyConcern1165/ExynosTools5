#!/usr/bin/env bash
set -euo pipefail
# Edit ANDROID_NDK to point to your NDK (example: /home/user/android-ndk-r25b)
ANDROID_NDK="/path/to/android-ndk"
BUILD_DIR="build-android"
rm -rf "$BUILD_DIR" && mkdir -p "$BUILD_DIR"
cmake -S . -B "$BUILD_DIR" -DCMAKE_TOOLCHAIN_FILE="$ANDROID_NDK/build/cmake/android.toolchain.cmake" -DANDROID_ABI=arm64-v8a -DANDROID_PLATFORM=android-31 -DCMAKE_BUILD_TYPE=Release
cmake --build "$BUILD_DIR" -- -j$(nproc)
echo "Built. Output in $BUILD_DIR"
