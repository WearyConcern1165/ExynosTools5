# ExynosTools - v1.2 functional (scaffold)

This repository is a scaffold to build the ExynosTools wrapper and produce a Winlator-compatible package (.tar.zst).
It intentionally does NOT include vendor blobs or proprietary code.

Use GitHub Actions included here to build and produce artifacts automatically.
