#!/usr/bin/env bash
set -euo pipefail
PKG_DIR=pkg
rm -rf "$PKG_DIR" && mkdir -p "$PKG_DIR/usr/lib"
cp build-android/libxeno_wrapper.so "$PKG_DIR/usr/lib/libxeno_wrapper.so" || true
mkdir -p "$PKG_DIR/etc/exynostools"
cat > "$PKG_DIR/etc/exynostools/meta.json" <<EOF
{ "name": "XclipseTools", "version": "v1.2-functional", "description": "Wrapper prototype" }
EOF
tar --zstd -cvf exynostools_v1.2-functional.tar.zst -C "$PKG_DIR" .
echo "Package created: exynostools_v1.2-functional.tar.zst"
