ExynosTools v1.2-functional - PR-ready scaffold

This repo contains an extended wrapper and CI workflow to build and inspect outputs. See .github/workflows/build.yml